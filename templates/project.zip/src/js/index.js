(function($) {
  "use strict";
  FastClick.attach(document.body);
  //do your thing.
  
})($);